1. package.json 생성
`npm init -y`
CMD창에서 해당 명령어 사용

2. 기본 패키지 설치
`npm install express ytdl-core`
CMD창에서 해당 명령어 사용

3. Node.js 실행
`node server.js`
CMD창에서 해당 명령어 사용

서버 실행 성공시
`Node.js 서버가 http://localhost:3000 에서 실행 중입니다.`
라는 문구 뜹니다.